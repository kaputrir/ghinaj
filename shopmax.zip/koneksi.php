<?php
	$server = "localhost";
	$username = "id12108331_toko";
	$pass = "toko123";
	$database = "id12108331_toko";
	
	$koneksi = mysqli_connect($server,$username,$pass,$database) OR DIE ("GAGAL KONEKSI");

	

	




?>