<?php
	$server = "localhost";
	$username = "root";
	$pass = "";
	$database = "penjualan";
	
	$koneksi = mysqli_connect($server,$username,$pass,$database) OR DIE ("GAGAL KONEKSI");

	

	




?>